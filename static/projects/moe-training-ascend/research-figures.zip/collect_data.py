"""Export measured results and global metrics stored beside training snapshots."""
import csv
import json
import math
import re
from collections import defaultdict
from pathlib import Path
from statistics import median, mean
ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / 'data'
OUT.mkdir(exist_ok=True)
def read(p): return json.loads((ROOT / p).read_text())
def lines(p): return [json.loads(x) for x in (ROOT / p).read_text().splitlines()]
def write_csv(name, rows):
    with (OUT / (name+'.csv')).open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
e = read('stage1/evidence.json')
block_samples=lines('runs/20261102T172139/production-block-matrix/samples.jsonl')
actor=lines('runs/20261104T100719/production-full-formal/samples.jsonl')
assert len(actor)==40 and len(block_samples)==1600
for key, stats in [('base', e['formal_actor']['statistics']['base']),('candidate',e['formal_actor']['statistics']['candidate'])]:
    assert math.isclose(median(r[key] for r in actor),stats['median_ms'],rel_tol=1e-12)
blocks=[]
for r in e['block_cases']:
    s=r['statistics']; raw=[x for x in block_samples if x['tokens']==r['tokens'] and x['distribution']==r['distribution']]
    assert len(raw)==100
    for arm in ['base','candidate']:assert math.isclose(median(x[arm] for x in raw),s[arm]['median_ms'],rel_tol=1e-12)
    blocks.append(dict(tokens=r['tokens'],distribution=r['distribution'],base_ms=s['base']['median_ms'],candidate_ms=s['candidate']['median_ms'],reduction=s['improvement'],ci_low=s['improvement_ci95'][0],ci_high=s['improvement_ci95'][1]))
quality=[]; state=[]; sources=[]
state_root=ROOT/'registered-fast-quality-state-20261109'
# evaluate() and compare_state() reduce over all 16 ranks before writing each record.
# Rank 0 is one copy of those global metrics, not an extra independent observation.
for layers in [2,48]:
    seeds=e['quality'][f'layers{layers}']['assessment']['seeds']
    end=1000 if layers==2 else 200
    for seed in seeds:
        for arm in ['A','B','C']:
            for p in sorted((state_root/f'layers-{layers}/seed-{seed}/{arm}').glob('step-*/rank-0/evaluation.json')):
                x=json.loads(p.read_text());assert x['layers']==layers and x['seed']==seed and x['arm']==arm
                sources.append(str(p.relative_to(ROOT)))
                for split,v in x['evaluation'].items():
                    quality.append(dict(layers=layers,seed=seed,arm=arm,step=x['step'],split=split,nll=v['mean_nll'],route_disagreement=v['route_disagreement'],scored_tokens=v['scored_tokens']))
                if layers==48 and x['step']==end and arm in ['B','C']:
                    bins=defaultdict(lambda:[0.,0.])
                    for name,v in x['state_differences'].items():
                        match=re.search(r'model.layers\.(\d+)\.',name)
                        if not match:continue
                        layer=int(match[1]);kind=name.rsplit(':',1)[1]
                        if kind not in ['parameter','gradient']:continue
                        bins[(layer,kind)][0]+=v['reference_l2']**2
                        bins[(layer,kind)][1]+=v['error_l2']**2
                    for (layer,kind),(ref,err) in sorted(bins.items()):
                        assert ref>0
                        state.append(dict(seed=seed,arm=arm,layer=layer,kind=kind,relative_l2=math.sqrt(err/ref)))
    for split,assessment in e['quality'][f'layers{layers}']['assessment']['splits'].items():
        for kind,arm in [('baseline_nll','B'),('candidate_nll','C')]:
            deltas=[]
            for seed in seeds:
                q={x['arm']:x for x in quality if x['layers']==layers and x['seed']==seed and x['step']==end and x['split']==split}
                assert set(q)=={'A','B','C'}
                deltas.append(q[arm]['nll']-q['A']['nll'])
            assert math.isclose(mean(deltas),assessment[kind]['mean'],abs_tol=1e-12)
arrival=read('backward/arrival-cast-study/20261110/summary.json')['samples']
assert arrival['complete'] and len(arrival['arm_samples'])==400 and arrival['timing_filtered_samples']==0
arr=[{k:r[k] for k in ['regime','pair_index','arm','full_pipeline_ms','rank0_preparation_ms']} for r in arrival['arm_samples']]
for regime,v in arrival['regimes'].items():
    for arm in ['base','candidate']:
        assert math.isclose(median(x['full_pipeline_ms'] for x in arr if x['regime']==regime and x['arm']==arm),v['metrics']['full_pipeline_ms'][arm]['median_ms'],rel_tol=1e-12)
prof=e['formal_actor']['profiler']['ranks'];assert len(prof)==16
for rank in prof:assert prof[rank]==prof['0']
export=dict(blocks=blocks,actor_samples=actor,actor_statistics=e['formal_actor']['statistics'],profile=prof['0'],quality=quality,quality_assessment={k:v['assessment'] for k,v in e['quality'].items()},state=state,arrival=arr,arrival_statistics={k:v['metrics'] for k,v in arrival['regimes'].items()},arrival_contrast=arrival['mechanism_contrast'],native_correctness=e['native_correctness'],metadata=dict(model=e['model'],model_revision=e['model_revision'],base=e['base'],devices=16,snapshot_metric_scope='Global reductions stored in rank-0 evaluation records; seeds are independent units.'))
# Avoid publishing host-specific paths from diagnostic metadata.
export['native_correctness'].pop('source',None)
(OUT/'plot-data.json').write_text(json.dumps(export,indent=2)+'\n')
for name,rows in [('block-cases',blocks),('block-pairs',block_samples),('actor-pairs',actor),('quality-snapshot-evaluations',quality),('final-state-layer-errors',state),('arrival-samples',arr)]:write_csv(name,rows)
(OUT/'sources.json').write_text(json.dumps(dict(snapshot_records=sources,measurements=['stage1/evidence.json','runs/20261102T172139/production-block-matrix/samples.jsonl','runs/20261104T100719/production-full-formal/samples.jsonl','backward/arrival-cast-study/20261110/summary.json'],verification=dict(block_pairs=len(block_samples),actor_pairs=len(actor),snapshot_records=len(sources),global_quality_observations=len(quality),layer_state_observations=len(state),arrival_arms=len(arr),published_medians_match=True,final_quality_means_match=True)),indent=2)+'\n')
print('Exported',len(sources),'snapshot evaluations;',len(state),'layer-state metrics; all source comparisons passed.')
