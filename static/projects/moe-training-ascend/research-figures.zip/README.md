# Layout-aware MoE Training: research figures

Open `index.html` for the portable research report. Figures are exported as SVG, PDF and PNG.

## Reproduce the figures

Install `requirements.txt`, then run `python plot_results.py`. The exported `data/plot-data.json` is sufficient; no NPU, model weights or network data fetch is needed.

`collect_data.py` refreshes the exports from the original `verl-pr-2` workspace. It reads paired measurement files and `evaluation.json` records beside the training snapshots. Evaluation and state-error values are already globally reduced across 16 ranks, so it reads rank 0 once per checkpoint. Seeds, not ranks or tokens, are the independent quality units. `data/sources.json` lists all source records and checked counts.

The final-state heatmaps use global per-parameter squared norms summed within each decoder layer, followed by a median over the three 48-layer seeds. They compare independent training trajectories and do not measure a same-state correctness test. Quality results concern the combined expert-computation and registered communication implementation.

`build_report.py` regenerates the portable HTML report, figure archive and figure insertions in the existing `RESEARCH.html`. Run it inside the original workspace after collecting and plotting. Existing snapshot payloads and experimental reports are not inputs to any mutation.
